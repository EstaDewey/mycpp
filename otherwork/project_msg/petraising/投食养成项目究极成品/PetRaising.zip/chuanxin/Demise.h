#ifndef DEMISE_H_INCLUDED
#define DEMISE_H_INCLUDED

#include <stdio.h>
#include "ChoicePet.h"

/*
简介:宠物死亡函数定义
作者:FRP - 浅挚
创建时间:2018/10/02
*/

using namespace std;

/**宠物死亡*/
int PetDemise();

#endif // DEMISE_H_INCLUDED
