#ifndef PETFEED_H_INCLUDED
#define PETFEED_H_INCLUDED

/*
简介:
作者:
创建时间:
*/

#include <iostream>
#include "Choicepet.h"
#include "Adventure.h"
#include "Parcel.h"

using namespace std;

int PetFeed();

#endif // PETFEED_H_INCLUDED
