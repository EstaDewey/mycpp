//
//  main.cpp
//  mycpp
//
//  Created by 杜威 on 2018/11/24.
//  Copyright © 2018年 dewey. All rights reserved.
//

#include "main.hpp"
#include "package.hpp"
#include <iostream>
#include <string>

using namespace std;

int main(){
    string goods[3] = {"1|2","2|4","3|5"};
    int goodskey = 2;
    int goodsNum = 2;
    Package pack;
    pack.AddMaterials(goods, goodskey,goodsNum);
    return 0;
}
