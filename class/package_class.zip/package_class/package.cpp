//
//  package.cpp
//  mycpp
//
//  Created by 杜威 on 2018/11/22.
//  Copyright © 2018年 dewey. All rights reserved.
//
#include <iostream>
#include "package.hpp"
#include <string>

using namespace std;


//物品展示
int Package::DisplayMaterials(string goods[]){
    cout << "DisplayMaterials" << endl;
    return 0;
}

//物品使用
int Package::UserParcelop(int num, int discard, int employ, int get){
    cout << "UserParcelop" << endl;
    return 0;
}

//新增物品
int Package::AddMaterials(string goods[],int goodskey,int goodsNums){
    cout << "AddMaterials" << endl;
    return 0;
}

//删除物品
int Package::DelMaterials(string goods[],int goodskey,int goodsNums){
    cout << "DelMaterials" << endl;
    return 0;
}



