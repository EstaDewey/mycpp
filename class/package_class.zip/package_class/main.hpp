//
//  main.hpp
//  mycpp
//
//  Created by 杜威 on 2018/11/24.
//  Copyright © 2018年 dewey. All rights reserved.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>

#endif /* main_hpp */
