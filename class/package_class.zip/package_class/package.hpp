//
//  package.hpp
//  mycpp
//
//  Created by 杜威 on 2018/11/22.
//  Copyright © 2018年 dewey. All rights reserved.
//

#ifndef package_hpp
#define package_hpp

#include <stdio.h>
#include <string>

using namespace std;

#endif /* package_hpp */
class Package
{
public:
    int goodsNum;//物品数量
    int page;//背包页数
    int size;//背包单页格子数目
    
public:
    int DisplayMaterials(string goods[]);//物品展示
    int UserParcelop(int num,int discard,int employ,int get);//物品使用
    int AddMaterials(string goods[],int goodskey,int goodsNums);//新增物品
    int DelMaterials(string goods[],int goodskey,int goodsNums);//删除物品
};

